import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import cors from "cors";
import { storage } from "./storage";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcryptjs";
import {
  insertUserSchema,
  insertOrganizationSchema,
  createCustomerSchema,
  createInvoiceSchema,
  type User,
} from "@shared/schema";

// Extend Express session to include user
declare global {
  namespace Express {
    interface User {
      id: string;
      username: string;
      email: string;
      organizationId: string | null;
      role: "OWNER" | "ADMIN" | "CUSTOMER";
    }
  }
}

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user is admin or owner
function isAdminOrOwner(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated() && (req.user!.role === "ADMIN" || req.user!.role === "OWNER")) {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin or Owner access required" });
}

// Validation middleware
function validateBody(schema: z.ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: fromZodError(error).message });
      } else {
        res.status(400).json({ message: "Invalid request body" });
      }
    }
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Security middleware
  app.use(helmet({
    contentSecurityPolicy: false, // Vite handles CSP in dev
  }));
  
  // CORS configuration
  app.use(cors({
    origin: process.env.NODE_ENV === "production" 
      ? process.env.ALLOWED_ORIGINS?.split(',') || []
      : true,
    credentials: true,
  }));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 minute
    max: 100, // 100 requests per minute
    message: "Muitas requisições, tente novamente em breve.",
    standardHeaders: true,
    legacyHeaders: false,
  });

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // 5 login attempts
    message: "Muitas tentativas de login, tente novamente em 15 minutos.",
    skipSuccessfulRequests: true,
  });

  app.use("/api/", limiter);

  // Session configuration
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "lucrei-secret-key-change-in-production",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
      },
    })
  );

  // Passport configuration
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: "email" },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user) {
            return done(null, false, { message: "Invalid credentials" });
          }

          const isValid = await bcrypt.compare(password, user.password);
          if (!isValid) {
            return done(null, false, { message: "Invalid credentials" });
          }

          return done(null, {
            id: user.id,
            username: user.username,
            email: user.email,
            organizationId: user.organizationId,
            role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
          });
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        return done(null, false);
      }
      done(null, {
        id: user.id,
        username: user.username,
        email: user.email,
        organizationId: user.organizationId,
        role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
      });
    } catch (error) {
      done(error);
    }
  });

  // AUTH ROUTES
  // Register
  app.post("/api/auth/register", authLimiter, async (req: Request, res: Response) => {
    try {
      const { email, password, username, name, organizationName } = req.body;

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create organization first
      const organization = await storage.createOrganization({
        name: organizationName || `${name}'s Organization`,
        email,
      });

      // Create user
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        name,
        organizationId: organization.id,
        role: "OWNER",
        emailVerified: false,
      });

      // Log activity
      await storage.createActivity({
        organizationId: organization.id,
        userId: user.id,
        action: "user_registered",
        entityType: "user",
        entityId: user.id,
        details: JSON.stringify({ email }),
      });

      // Auto login after registration
      req.login(
        {
          id: user.id,
          username: user.username,
          email: user.email,
          organizationId: user.organizationId,
          role: user.role as "OWNER" | "ADMIN" | "CUSTOMER",
        },
        (err) => {
          if (err) {
            return res.status(500).json({ message: "Registration successful but login failed" });
          }
          res.json({
            user: {
              id: user.id,
              username: user.username,
              email: user.email,
              name: user.name,
              organizationId: user.organizationId,
              role: user.role,
            },
          });
        }
      );
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Login
  app.post("/api/auth/login", authLimiter, (req: Request, res: Response, next: NextFunction) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return res.status(500).json({ message: "Login failed" });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Login failed" });
        }
        res.json({ user });
      });
    })(req, res, next);
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.logout(() => {
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/auth/me", isAuthenticated, (req: Request, res: Response) => {
    res.json({ user: req.user });
  });

  // ORGANIZATIONS ROUTES
  // Get current organization
  app.get("/api/organizations/current", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(404).json({ message: "No organization found" });
      }
      const organization = await storage.getOrganization(req.user!.organizationId);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // Update organization
  app.put("/api/organizations/:id", isAuthenticated, isAdminOrOwner, async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      if (id !== req.user!.organizationId) {
        return res.status(403).json({ message: "Cannot update other organizations" });
      }
      const organization = await storage.updateOrganization(id, req.body);
      res.json(organization);
    } catch (error) {
      res.status(500).json({ message: "Failed to update organization" });
    }
  });

  // CUSTOMERS ROUTES
  // Get all customers for organization
  app.get("/api/customers", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const customers = await storage.getCustomersByOrganization(req.user!.organizationId);
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customers" });
    }
  });

  // Get single customer
  app.get("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  // Create customer
  app.post(
    "/api/customers",
    isAuthenticated,
    validateBody(createCustomerSchema),
    async (req: Request, res: Response) => {
      try {
        const customer = await storage.createCustomer({
          ...req.body,
          organizationId: req.user!.organizationId!,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "customer_created",
          entityType: "customer",
          entityId: customer.id,
          details: JSON.stringify({ name: customer.name }),
        });

        res.status(201).json(customer);
      } catch (error) {
        res.status(500).json({ message: "Failed to create customer" });
      }
    }
  );

  // Update customer
  app.put("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      const customer = await storage.updateCustomer(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_updated",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: customer?.name }),
      });

      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  // Delete customer
  app.delete("/api/customers/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getCustomer(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }

      await storage.deleteCustomer(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "customer_deleted",
        entityType: "customer",
        entityId: req.params.id,
        details: JSON.stringify({ name: existing.name }),
      });

      res.json({ message: "Customer deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete customer" });
    }
  });

  // INVOICES ROUTES
  // Get all invoices for organization
  app.get("/api/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const invoices = await storage.getInvoicesByOrganization(req.user!.organizationId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get invoices by customer
  app.get("/api/customers/:customerId/invoices", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const customer = await storage.getCustomer(req.params.customerId);
      if (!customer || customer.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Customer not found" });
      }
      const invoices = await storage.getInvoicesByCustomer(req.params.customerId);
      res.json(invoices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Get single invoice
  app.get("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const invoice = await storage.getInvoice(req.params.id);
      if (!invoice || invoice.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }
      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Create invoice
  app.post(
    "/api/invoices",
    isAuthenticated,
    validateBody(createInvoiceSchema),
    async (req: Request, res: Response) => {
      try {
        // Verify customer belongs to organization
        const customer = await storage.getCustomer(req.body.customerId);
        if (!customer || customer.organizationId !== req.user!.organizationId) {
          return res.status(400).json({ message: "Invalid customer" });
        }

        // Generate invoice number
        const timestamp = Date.now();
        const invoiceNumber = `INV-${timestamp}`;

        const invoice = await storage.createInvoice({
          ...req.body,
          organizationId: req.user!.organizationId!,
          invoiceNumber,
        });

        await storage.createActivity({
          organizationId: req.user!.organizationId!,
          userId: req.user!.id,
          action: "invoice_created",
          entityType: "invoice",
          entityId: invoice.id,
          details: JSON.stringify({ invoiceNumber, amount: invoice.amount }),
        });

        res.status(201).json(invoice);
      } catch (error) {
        res.status(500).json({ message: "Failed to create invoice" });
      }
    }
  );

  // Update invoice
  app.put("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      const invoice = await storage.updateInvoice(req.params.id, req.body);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_updated",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: invoice?.invoiceNumber }),
      });

      res.json(invoice);
    } catch (error) {
      res.status(500).json({ message: "Failed to update invoice" });
    }
  });

  // Delete invoice
  app.delete("/api/invoices/:id", isAuthenticated, async (req: Request, res: Response) => {
    try {
      const existing = await storage.getInvoice(req.params.id);
      if (!existing || existing.organizationId !== req.user!.organizationId) {
        return res.status(404).json({ message: "Invoice not found" });
      }

      await storage.deleteInvoice(req.params.id);

      await storage.createActivity({
        organizationId: req.user!.organizationId!,
        userId: req.user!.id,
        action: "invoice_deleted",
        entityType: "invoice",
        entityId: req.params.id,
        details: JSON.stringify({ invoiceNumber: existing.invoiceNumber }),
      });

      res.json({ message: "Invoice deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete invoice" });
    }
  });

  // METRICS ROUTES
  app.get("/api/metrics", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const metrics = await storage.getMetrics(req.user!.organizationId);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch metrics" });
    }
  });

  // ACTIVITIES ROUTES
  app.get("/api/activities", isAuthenticated, async (req: Request, res: Response) => {
    try {
      if (!req.user!.organizationId) {
        return res.status(400).json({ message: "No organization" });
      }
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const activities = await storage.getActivitiesByOrganization(req.user!.organizationId, limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
