import bcrypt from "bcryptjs";
import { storage } from "./storage";

async function seed() {
  console.log("Starting seed...");

  try {
    const existingUser = await storage.getUserByEmail("demo@lucrei.com");
    
    if (existingUser) {
      console.log("✓ Demo data already exists!");
      console.log("\nLogin credentials:");
      console.log("Email: demo@lucrei.com");
      console.log("Password: demo123");
      console.log("\nOr use:");
      console.log("Email: admin@lucrei.com");
      console.log("Password: demo123");
      process.exit(0);
    }

    const hashedPassword = await bcrypt.hash("demo123", 10);

    const org = await storage.createOrganization({
      name: "Demo Company",
      email: "demo@lucrei.com",
    });
    console.log("✓ Created organization:", org.name);

    const owner = await storage.createUser({
      username: "demo",
      email: "demo@lucrei.com",
      password: hashedPassword,
      name: "Demo User",
      organizationId: org.id,
      role: "OWNER",
      emailVerified: true,
    });
    console.log("✓ Created owner user:", owner.email);

    const admin = await storage.createUser({
      username: "admin",
      email: "admin@lucrei.com",
      password: hashedPassword,
      name: "Admin User",
      organizationId: org.id,
      role: "ADMIN",
      emailVerified: true,
    });
    console.log("✓ Created admin user:", admin.email);

    const customers = await Promise.all([
      storage.createCustomer({
        name: "João Silva",
        email: "joao@example.com",
        phone: "(11) 98765-4321",
        organizationId: org.id,
      }),
      storage.createCustomer({
        name: "Maria Santos",
        email: "maria@example.com",
        phone: "(21) 99876-5432",
        organizationId: org.id,
      }),
      storage.createCustomer({
        name: "Carlos Oliveira",
        email: "carlos@example.com",
        phone: "(31) 97654-3210",
        organizationId: org.id,
      }),
    ]);
    console.log("✓ Created", customers.length, "customers");

    const invoices = await Promise.all([
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        amount: 1500.00,
        status: "paid",
        dueDate: new Date("2024-01-15"),
        description: "Consultoria em desenvolvimento web",
      }),
      storage.createInvoice({
        customerId: customers[1].id,
        organizationId: org.id,
        amount: 2500.00,
        status: "pending",
        dueDate: new Date("2024-02-20"),
        description: "Design de interface e UX",
      }),
      storage.createInvoice({
        customerId: customers[2].id,
        organizationId: org.id,
        amount: 3200.00,
        status: "overdue",
        dueDate: new Date("2024-01-05"),
        description: "Manutenção de sistema",
      }),
      storage.createInvoice({
        customerId: customers[0].id,
        organizationId: org.id,
        amount: 1800.00,
        status: "pending",
        dueDate: new Date("2024-03-10"),
        description: "Desenvolvimento de API",
      }),
    ]);
    console.log("✓ Created", invoices.length, "invoices");

    console.log("\n✅ Seed completed successfully!");
    console.log("\nLogin credentials:");
    console.log("Email: demo@lucrei.com");
    console.log("Password: demo123");
    console.log("\nOr use:");
    console.log("Email: admin@lucrei.com");
    console.log("Password: demo123");

    process.exit(0);
  } catch (error) {
    console.error("❌ Seed failed:", error);
    process.exit(1);
  }
}

seed();
