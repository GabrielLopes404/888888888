# LUCREI - Design Guidelines
## SaaS de Gestão Financeira Empresarial (2025/2026 Global Standards)

## Design Approach: Premium Financial SaaS System
**Reference Framework**: Stripe's trust-building aesthetics + Linear's modern typography + Notion's organized hierarchy + Vercel's minimalist precision

**Core Principle**: Professional, trustworthy, and efficient - designed for financial decision-makers who value clarity and precision over decoration.

---

## Typography System

**Primary Font**: Inter (Google Fonts)
- Display/Hero: 600 weight, 48-72px (desktop), 32-40px (mobile)
- H1: 600 weight, 36-48px
- H2: 600 weight, 28-32px  
- H3: 600 weight, 20-24px
- Body Large: 400 weight, 18px, line-height 1.6
- Body: 400 weight, 16px, line-height 1.5
- Body Small: 400 weight, 14px, line-height 1.5
- Labels/Captions: 500 weight, 12-13px, uppercase tracking

**Number Display Font**: JetBrains Mono (for financial metrics, currency values)
- Ensures perfect alignment in tables and dashboards
- Use for: MRR displays, invoice amounts, client counts

---

## Layout & Spacing System

**Tailwind Spacing Primitives**: Consistent use of 2, 4, 8, 12, 16, 24, 32 units
- Component padding: p-4, p-6, p-8
- Section spacing: py-16, py-24, py-32 (desktop), py-12, py-16 (mobile)
- Card gaps: gap-4, gap-6
- Grid gaps: gap-8 (desktop), gap-4 (mobile)

**Container System**:
- Max-width: 1280px (xl) for app dashboards
- Max-width: 1440px (2xl) for landing page
- Sidebar width: 280px (desktop), hidden/drawer (mobile)
- Header height: 64px (fixed)

**Grid Patterns**:
- Metrics cards: 3-column on desktop (lg:grid-cols-3), 1-column mobile
- Client/Invoice tables: full-width with horizontal scroll on mobile
- Dashboard widgets: 2-column main layout (8-4 ratio for main content + sidebar)

---

## Component Library

### Navigation
**Header** (64px fixed height):
- Logo left (140px width)
- Main nav center: Dashboard, Clientes, Faturas, Configurações
- User menu right: Avatar + dropdown (name, role badge, settings, logout)
- Mobile: Hamburger menu with slide-out drawer

**Sidebar** (Admin/App area):
- 280px width, bg subtle, fixed position
- Navigation groups with icons (Heroicons)
- Active state: accent background with left border (4px)
- Collapsed mode: 64px with icon-only on hover

**Mobile Bottom Nav**:
- 56px height, fixed bottom
- 4-5 primary actions with icons
- Active state with color fill

### Cards & Containers
**Dashboard Cards**:
- White/surface background, border 1px subtle
- Rounded corners: rounded-xl (12px)
- Padding: p-6 (desktop), p-4 (mobile)
- Shadow: subtle elevation (shadow-sm)
- Header: Title + optional action button
- Metric display: Large number (36-48px) + label + trend indicator (↑↓%)

**Data Tables**:
- Alternating row backgrounds for readability
- Sticky header on scroll
- Row height: 56px minimum
- Column padding: px-4 py-3
- Actions column (right-aligned): Edit, Delete icons
- Mobile: Convert to stacked cards with key info visible

### Forms & Inputs
**Input Fields**:
- Height: 44px (touch-friendly)
- Border: 1px, rounded-lg (8px)
- Focus state: 2px accent border, no shadow
- Labels: above input, 14px font-medium
- Helper text: 12px below input
- Error state: red border + error message

**Buttons**:
- Primary: Full accent background, 500 font-weight, px-6 py-3, rounded-lg
- Secondary: Outline with 1px border, background transparent
- Ghost: No border, subtle hover background
- Danger: Red variant for destructive actions
- Loading state: Spinner icon + disabled
- Icon buttons: 40px square, rounded-lg

### Financial Components
**Invoice Card**:
- Client name (16px font-semibold)
- Amount (24px JetBrains Mono, font-bold)
- Due date + status badge
- Payment button (if pending)
- Icons for download/view PDF

**Pricing Cards** (Landing):
- 3 tiers: Pessoal, Empresarial, Enterprise
- Card hover: lift effect (shadow-xl, -translate-y-1)
- Most popular: highlighted border (2px accent)
- Price display: Large (48px) + "/mês" small
- Feature list with checkmarks (Heroicons)
- CTA button prominent at bottom

**Metrics Display**:
- KPI card layout: Icon/emoji → Value (large) → Label → Change (%)
- Charts: Use Recharts library for line/bar graphs
- Time period selector: Tabs (7d, 30d, 90d, 12m)

### Status Indicators
**Status Badges**:
- Pill shape: rounded-full, px-3 py-1, 12px font-medium
- PENDING: yellow background, dark text
- PAID: green background, white text
- OVERDUE: red background, white text
- CANCELLED: gray background, dark text

**Role Badges**:
- OWNER: Purple gradient
- ADMIN: Blue solid
- CUSTOMER: Gray outline

---

## Page-Specific Layouts

### Landing Page (/)
**Hero Section** (80vh):
- Large centered headline (48-72px): "Controle financeiro simples para quem quer crescer"
- Subheadline (20px, max-width 600px)
- Primary CTA: "Começar agora — 7 dias grátis" (large button, px-8 py-4)
- Secondary CTA: "Ver demonstração" (ghost button)
- Hero image/illustration: Dashboard preview on right (60% width, floating with subtle shadow)

**Benefits Section** (py-24):
- 3-column grid of feature cards
- Icon (64px) → Title → Description
- Each card: p-8, hover lift effect

**Pricing Section** (py-32):
- 3 pricing tiers in grid
- Toggle: Mensal/Anual (save 20%)
- Cards with all features

**Testimonials** (py-24):
- 3 testimonials in grid
- Avatar + name + role + company
- Quote (18px italic)

**Footer**:
- 4-column layout: Product, Company, Resources, Contact
- Logo + tagline
- Social icons
- Newsletter signup form
- Legal links (Termos, Privacidade)

### Dashboard (/app)
**Overview Layout**:
- Top: 4 metric cards (MRR, Clientes Ativos, Faturas Pendentes, Taxa Conversão)
- Main area: 2-column (8-4 split)
  - Left: Recent invoices table + Revenue chart
  - Right: Quick actions + Notifications + Tasks
- Mobile: Single column stack

### Admin Dashboard (/dashboard)
**Metrics Heavy**:
- Top: 5 KPI cards (Revenue, MRR, ARR, Churn, New Signups)
- Charts row: Revenue over time (line) + Subscriptions by plan (bar)
- Tables: Recent users + Organizations + Payment failures
- Filters: Date range, Organization, Status

---

## Images

**Hero Image**: 
- Professional dashboard screenshot/mockup showing the LUCREI interface
- Placed on right side (60% width on desktop)
- Floating effect with shadow-2xl, slight rotation (-2deg)
- Shows key features: metrics, client list, modern UI
- Mobile: Stacked below hero text, full width

**Feature Section Images**:
- 3 feature screenshots showcasing: Client Management, Invoice Creation, Financial Reports
- Placed within feature cards as visual proof
- Rounded corners (rounded-xl), subtle border

**Testimonial Avatars**:
- Client photos (80px rounded-full)
- Professional business headshots
- Grayscale with color on hover (optional polish)

---

## Animations & Interactions
**Minimal & Purposeful**:
- Card hover: subtle lift (transform translateY -4px, shadow increase)
- Button hover: slight scale (1.02), background darken
- Page transitions: fade-in only, no complex animations
- Loading states: simple spinner, skeleton screens for tables
- Toast notifications: slide-in from top-right

**Dashboard Interactions**:
- Smooth chart animations on load (0.5s ease)
- Table sorting: instant, no animation
- Modal open/close: fade + scale (0.2s)

---

## Icons
**Library**: Heroicons (outline for nav, solid for emphasis)
- Navigation: outline style
- Actions: outline style (edit, delete, view)
- Status/Success: solid style
- Size: 20px standard, 24px for headers, 16px for small contexts

---

## Accessibility
- Focus states: 2px accent ring on all interactive elements
- Color contrast: WCAG AAA for body text, AA for UI elements
- Keyboard navigation: Full support with visible focus
- Screen reader: Proper ARIA labels on all controls
- Touch targets: Minimum 44x44px
- Forms: Clear error messages, field validation on blur

---

**Final Note**: This design system prioritizes trust, clarity, and professional aesthetics appropriate for a financial management platform used by business decision-makers. Every element serves the goal of making complex financial data accessible and actionable.