import LandingPage from '../../pages/LandingPage';

export default function LandingPageExample() {
  return <LandingPage />;
}
