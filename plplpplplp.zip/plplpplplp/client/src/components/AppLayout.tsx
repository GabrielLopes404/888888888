import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Users,
  FileText,
  Settings,
  LogOut,
  Menu,
  X,
  Sparkles,
  Moon,
  Sun,
  Receipt,
  BarChart3,
  Import,
  HelpCircle,
  ChevronDown,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import HelpButton from "@/components/HelpButton";

interface AppLayoutProps {
  children: React.ReactNode;
}

interface NavItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

const navigation: NavItem[] = [
  { name: "Página inicial", href: "/app/dashboard", icon: LayoutDashboard },
  { name: "Transações", href: "/app/transactions", icon: Receipt },
  { name: "Contatos", href: "/app/customers", icon: Users },
  { name: "Relatórios", href: "/app/reports", icon: BarChart3 },
  { name: "Importações", href: "/app/imports", icon: Import },
  { name: "Conciliações (OFX)", href: "/app/reconciliations", icon: FileText },
];

export default function AppLayout({ children }: AppLayoutProps) {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('darkMode');
      return saved ? JSON.parse(saved) : false;
    }
    return false;
  });

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await fetch("/api/auth/me", {
          credentials: "include",
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          setLocation("/login");
        }
      } catch (error) {
        console.error("Failed to fetch user:", error);
        setLocation("/login");
      }
    };

    fetchUser();
  }, [setLocation]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });

      toast({
        title: "Logout realizado",
        description: "Até logo!",
      });

      setLocation("/");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erro ao fazer logout",
        description: "Tente novamente.",
      });
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="lg:grid lg:grid-cols-[280px_1fr]">
        <aside
          className={`fixed inset-y-0 left-0 z-50 w-72 bg-card border-r transform transition-transform duration-200 ease-in-out lg:relative lg:translate-x-0 ${
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          }`}
        >
          <div className="flex h-16 items-center justify-between px-6 border-b">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                LUCREI
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <nav className="flex-1 space-y-1 px-4 py-4 overflow-y-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.href;

              return (
                <Button
                  key={item.name}
                  variant={isActive ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 h-10"
                  onClick={() => {
                    setLocation(item.href);
                    setSidebarOpen(false);
                  }}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm">{item.name}</span>
                </Button>
              );
            })}
          </nav>

          <div className="border-t">
            <div className="p-4 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start gap-3 h-10"
                onClick={() => {
                  setLocation("/app/settings");
                  setSidebarOpen(false);
                }}
              >
                <Settings className="h-4 w-4" />
                <span className="text-sm">Configurações</span>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-10">
                    <HelpCircle className="h-4 w-4" />
                    <span className="text-sm flex-1 text-left">Ajuda</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem>Videoaulas para iniciantes</DropdownMenuItem>
                  <DropdownMenuItem>Guias de ajuda</DropdownMenuItem>
                  <DropdownMenuItem>Dicas</DropdownMenuItem>
                  <DropdownMenuItem>Dê seu feedback</DropdownMenuItem>
                  <DropdownMenuItem>Outros canais de ajuda</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="border-t p-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-3 h-auto py-2 px-2">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-semibold text-primary">
                        {user.name?.charAt(0).toUpperCase() || user.username?.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0 text-left">
                      <p className="text-sm font-medium truncate">{user.name || user.username}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                    <ChevronDown className="h-4 w-4 flex-shrink-0" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setLocation("/app/profile")}>
                    Meu perfil de usuário
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/settings")}>
                    Configurações de {user.name || user.username}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/accounts")}>
                    Minhas contas
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/categories")}>
                    Categorias
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/cost-centers")}>
                    Centros de Custo
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/bank-accounts")}>
                    Contas Bancárias
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/documents")}>
                    Documentos
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/tags")}>
                    Tags / Marcadores
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/export")}>
                    Exportar dados
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setLocation("/app/subscription")}>
                    Gerenciar minha assinatura
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/app/pricing")}>
                    Assinar plano...
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <div className="flex flex-col min-h-screen">
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-2 text-center text-sm">
            <span className="font-medium">Seu período de avaliação termina em 6 dias</span>
            <span className="mx-2">·</span>
            <span>Você pode efetivar a sua assinatura a qualquer momento dentro deste período clicando no botão </span>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 h-6 px-3 mx-1">
              Assinar
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 h-6 px-3">
              Fale com um de nossos especialistas
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20 h-6 px-3 ml-2">
              Ativar
            </Button>
          </div>
          <header className="sticky top-0 z-30 h-16 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex h-full items-center gap-2 px-4 sm:px-6">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex-1" />
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="20" 
                      height="20" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                    </svg>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <div className="p-3 border-b">
                    <h3 className="font-semibold">Notificações</h3>
                  </div>
                  <div className="p-6 text-center text-sm text-muted-foreground">
                    Você não possui novas notificações
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="relative">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="20" 
                      height="20" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" />
                    </svg>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-80">
                  <div className="p-3 border-b">
                    <h3 className="font-semibold">Alertas</h3>
                  </div>
                  <div className="p-6 text-center text-sm text-muted-foreground">
                    Você não possui novas notificações
                  </div>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                variant="ghost"
                size="icon"
                onClick={toggleDarkMode}
                title={darkMode ? "Modo claro" : "Modo escuro"}
              >
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            </div>
          </header>

          <main className="flex-1 p-4 sm:p-6 lg:p-8">
            {children}
          </main>
        </div>
      </div>
      
      <HelpButton />
    </div>
  );
}
