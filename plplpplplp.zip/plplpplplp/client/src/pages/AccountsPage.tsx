import { useState } from "react";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Wallet, TrendingUp, TrendingDown, DollarSign, CreditCard, Building, Pencil, Trash2, Eye, MoreHorizontal, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { motion } from "framer-motion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

export default function AccountsPage() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    type: "checking",
    institution: "",
    initialBalance: "",
    currency: "BRL",
    description: "",
  });

  const accounts = [
    {
      id: 1,
      name: "Conta Principal",
      type: "checking",
      institution: "Banco do Brasil",
      balance: 45750.80,
      currency: "BRL",
      lastTransaction: "Hoje, 10:32",
      transactions: 1234,
      trend: "up",
      change: 12.5,
      color: "blue",
    },
    {
      id: 2,
      name: "Conta Empresarial",
      type: "business",
      institution: "Itaú",
      balance: 128300.50,
      currency: "BRL",
      lastTransaction: "Ontem, 15:20",
      transactions: 856,
      trend: "up",
      change: 8.3,
      color: "green",
    },
    {
      id: 3,
      name: "Poupança",
      type: "savings",
      institution: "Nubank",
      balance: 25000.00,
      currency: "BRL",
      lastTransaction: "3 dias atrás",
      transactions: 45,
      trend: "up",
      change: 2.1,
      color: "purple",
    },
    {
      id: 4,
      name: "Cartão de Crédito",
      type: "credit",
      institution: "Santander",
      balance: -5420.30,
      currency: "BRL",
      lastTransaction: "Hoje, 08:15",
      transactions: 342,
      trend: "down",
      change: -15.2,
      color: "red",
    },
  ];

  const balanceHistory = [
    { month: "Jan", valor: 35000 },
    { month: "Fev", valor: 38000 },
    { month: "Mar", valor: 42000 },
    { month: "Abr", valor: 45000 },
    { month: "Mai", valor: 43000 },
    { month: "Jun", valor: 48000 },
  ];

  const totalBalance = accounts.reduce((acc, account) => acc + account.balance, 0);
  const totalAccounts = accounts.length;
  const activeAccounts = accounts.filter(a => a.balance > 0).length;

  const getAccountIcon = (type: string) => {
    switch (type) {
      case "checking": return Wallet;
      case "business": return Building;
      case "savings": return DollarSign;
      case "credit": return CreditCard;
      default: return Wallet;
    }
  };

  const getAccountTypeLabel = (type: string) => {
    switch (type) {
      case "checking": return "Conta Corrente";
      case "business": return "Conta Empresarial";
      case "savings": return "Poupança";
      case "credit": return "Cartão de Crédito";
      default: return type;
    }
  };

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Minhas Contas
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie todas as suas contas financeiras em um só lugar
            </p>
          </div>
          <Button onClick={() => setIsCreateOpen(true)} className="gap-2 shadow-lg shadow-primary/20">
            <Plus className="h-4 w-4" />
            Nova Conta
          </Button>
        </motion.div>

        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-3">
          <Card className="border-l-4 border-l-blue-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Saldo Total</p>
                  <p className="text-2xl font-bold text-blue-600 mt-2">
                    R$ {totalBalance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                  <Wallet className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de Contas</p>
                  <p className="text-2xl font-bold mt-2">
                    {totalAccounts}
                  </p>
                </div>
                <div className="h-12 w-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                  <Building className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-purple-500">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Contas Ativas</p>
                  <p className="text-2xl font-bold mt-2">
                    {activeAccounts}
                  </p>
                </div>
                <div className="h-12 w-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle>Evolução do Saldo Total</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={balanceHistory}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="valor" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-2">
          {accounts.map((account) => {
            const Icon = getAccountIcon(account.type);
            return (
              <Card key={account.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`h-12 w-12 bg-${account.color}-100 dark:bg-${account.color}-900/20 rounded-full flex items-center justify-center`}>
                        <Icon className={`h-6 w-6 text-${account.color}-600`} />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{account.name}</CardTitle>
                        <CardDescription>{account.institution}</CardDescription>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setSelectedAccount(account);
                          setIsDetailOpen(true);
                        }}>
                          <Eye className="h-4 w-4 mr-2" />
                          Ver detalhes
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Pencil className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Saldo Atual</p>
                    <p className={`text-3xl font-bold ${account.balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                      R$ {Math.abs(account.balance).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div>
                      <p className="text-xs text-muted-foreground">Última movimentação</p>
                      <p className="text-sm font-medium">{account.lastTransaction}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {account.trend === "up" ? (
                        <ArrowUpRight className="h-4 w-4 text-green-600" />
                      ) : (
                        <ArrowDownRight className="h-4 w-4 text-red-600" />
                      )}
                      <span className={`text-sm font-semibold ${account.trend === "up" ? "text-green-600" : "text-red-600"}`}>
                        {account.change > 0 ? "+" : ""}{account.change}%
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge variant="outline">{getAccountTypeLabel(account.type)}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {account.transactions} transações
                    </span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </motion.div>
      </motion.div>

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Nova Conta Financeira</DialogTitle>
            <DialogDescription>
              Adicione uma nova conta para gerenciar seus recursos
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            setIsCreateOpen(false);
          }}>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="accountName">Nome da Conta *</Label>
                <Input
                  id="accountName"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Conta Corrente"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="accountType">Tipo de Conta *</Label>
                  <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="checking">Conta Corrente</SelectItem>
                      <SelectItem value="savings">Poupança</SelectItem>
                      <SelectItem value="business">Conta Empresarial</SelectItem>
                      <SelectItem value="credit">Cartão de Crédito</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency">Moeda</Label>
                  <Select value={formData.currency} onValueChange={(value) => setFormData({ ...formData, currency: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BRL">Real (R$)</SelectItem>
                      <SelectItem value="USD">Dólar ($)</SelectItem>
                      <SelectItem value="EUR">Euro (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="institution">Instituição Financeira</Label>
                <Input
                  id="institution"
                  value={formData.institution}
                  onChange={(e) => setFormData({ ...formData, institution: e.target.value })}
                  placeholder="Ex: Banco do Brasil"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="initialBalance">Saldo Inicial</Label>
                <Input
                  id="initialBalance"
                  type="number"
                  step="0.01"
                  value={formData.initialBalance}
                  onChange={(e) => setFormData({ ...formData, initialBalance: e.target.value })}
                  placeholder="0,00"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição (Opcional)</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Informações adicionais"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit">Criar Conta</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Detalhes da Conta</DialogTitle>
          </DialogHeader>
          {selectedAccount && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-3">
                <div className="h-16 w-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <Wallet className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">{selectedAccount.name}</h3>
                  <p className="text-sm text-muted-foreground">{selectedAccount.institution}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Tipo</p>
                  <p className="font-semibold mt-1">{getAccountTypeLabel(selectedAccount.type)}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Moeda</p>
                  <p className="font-semibold mt-1">{selectedAccount.currency}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium text-muted-foreground">Saldo Atual</p>
                <p className={`text-3xl font-bold mt-1 ${selectedAccount.balance >= 0 ? "text-green-600" : "text-red-600"}`}>
                  R$ {Math.abs(selectedAccount.balance).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total de Transações</p>
                  <p className="font-semibold mt-1">{selectedAccount.transactions}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Última Movimentação</p>
                  <p className="font-semibold mt-1">{selectedAccount.lastTransaction}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
